<?php 
	
	$db = mysqli_connect("localhost", "root", "", "harapan_medan");

