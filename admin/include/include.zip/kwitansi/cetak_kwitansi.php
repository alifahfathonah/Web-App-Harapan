<?php 
date_default_timezone_set("Asia/Jakarta");
	require_once 'dompdf/autoload.inc.php';

	use Dompdf\Dompdf; 

	$dompdf = new Dompdf();

	$php_file = file_get_contents("kwitansi.php");
	$dompdf -> loadHtml($php_file);

	$dompdf -> setPaper('Latter', 'portrait');

	$dompdf -> render();
echo "end!";exit;
	$dompdf -> stream("kwitansi", array("Attachment" => 0));