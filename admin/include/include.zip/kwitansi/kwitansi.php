<!DOCTYPE html>
<html>
<head>
  <title>KWITANSI</title>
  <link rel="stylesheet" type="text/css" href="print.css">
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="img-logo">         
      </div>
      <div class="judul">
        <h3>YAYASAN PENDIDIKAN HARAPAN</h3>
        <h3>Jln. Imam Bonjol No.35 Medan</h3>
      </div>
      <h3 align="center">T.P<br/>2020 / 2021</h3>
    </div>
    <div class="body-tansi">
        <div class="box1">
            <p>
              <strong>PROMO ULANG TAHUN BULAN FEBRUARY 2020 DISKON 50% DARI UANG PANGKAL</strong>
            </p>
        </div>
        <div class="isi-box">
          <p>Uang Masuk Siswa Baru SMP HARAPAN 1 </p>
          <table>
            <tr>
              <td>1. UNIT SEKOLAH </td>
              <td> :</td>
              <td></td>
            </tr>
            <tr>
              <td>2. NAMA SISWA </td>
              <td> :</td>
              <td></td>
            </tr>
            <tr>
              <td>3. JENIS KELAMIN </td>
              <td> :</td>
              <td></td>
            </tr>
            <tr>
              <td>4. KELAS </td>
              <td> :</td>
              <td></td>
            </tr>
            <tr>
              <td>5. UNTUK PEMBAYARAN </td>
              <td> :</td>
              <td></td>
            </tr>
          </table>

          <table align="center">
            <tr>
              <td>1. UANG PENDAFTARAN </td>
              <td> :</td>
              <td></td>
            </tr>
            <tr>
              <td>2. UANG PANGKAL </td>
              <td> :</td>
              <td></td>
            </tr>
            <tr>
              <td>3. UANG SEKOLAH </td>
              <td> :</td>
              <td></td>
            </tr>
            <tr>
              <td>4. UANG SARANA PENDIDIKAN </td>
              <td> :</td>
              <td></td>
            </tr>
            <tr>
              <th>JUMLAH </th>
              <td colspan="2"> :</td>
              <th></th>
            </tr>
          </table>
        </div>
        <div class="footer-box">
          <div class="footer1">
            <p>
              <strong>NB</strong> : Maaf Semua Uang Yang Sudah Dibayarkan<br/> Tidak Bisa Di Ambi Kembali, Terimakasih.
            </p>
            <p class="top-p">(Tanda Tangan Wali Murid)</p>
            <div class="top-r">
              <p align="right">
                MEDAN, 00 FEBRUARY 2020
              </p>
              <p align="right">T.U.SMP HARAPAN 1</p>
              <p class="top-p" align="right">(FAUZIAH LUBIS, SS)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
</body>
</html>